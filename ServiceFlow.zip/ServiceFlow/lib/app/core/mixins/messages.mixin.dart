import 'package:flutter/material.dart';

mixin UiFeedbackMixin {
  void showSuccess(BuildContext context, String message) {
    _showSnackBar(context, message, Colors.green);
  }

  void showError(BuildContext context, String message) {
    _showSnackBar(context, message, Colors.red);
  }

  void showWarning(BuildContext context, String message) {
    _showSnackBar(context, message, Colors.orange);
  }

  void showInfo(BuildContext context, String message) {
    _showSnackBar(context, message, Colors.blue);
  }

  void _showSnackBar(BuildContext context, String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }
}
