abstract class BaseModel {
  final int? id;
  final DateTime? createdAt;

  BaseModel({this.id, this.createdAt});

  Map<String, dynamic> toMap();

  // Nota arquitetural: O construtor fromMap não pode ser definido na interface,
  // mas as entidades filhas DEVEM implementar `factory Entity.fromMap(Map<String, dynamic> map)`
}
