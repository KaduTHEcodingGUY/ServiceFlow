import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

abstract class BaseRepository<T> {
  final Dio _dio;
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();

  BaseRepository(this._dio) {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          // Injeção do JWT do Supabase
          final token = await _secureStorage.read(key: 'jwt_token');
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          return handler.next(options);
        },
        onError: (DioException e, handler) {
          // Tratamento de erros global
          return handler.next(e);
        },
      ),
    );
  }

  Dio get client => _dio;

  Future<List<T>> getAll();
  Future<T?> getById(int id);
  Future<T> create(T item);
  Future<T> update(T item);
  Future<void> delete(int id);
}
