import 'package:flutter/material.dart';
import 'package:serviceflow/app/modules/auth/presentation/pages/login_page.dart';
import 'package:serviceflow/app/modules/dashboard/presentation/pages/dashboard_page.dart';
import 'package:serviceflow/app/modules/splash/presentation/pages/splash_page.dart';

class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String dashboard = '/dashboard';

  static Map<String, WidgetBuilder> get routes => {
        splash: (context) => const SplashPage(),
        login: (context) => const LoginPage(),
        dashboard: (context) => const DashboardPage(),
      };
}
