import 'package:flutter/material.dart';
import 'package:serviceflow/app/app_routes.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.of(context).pushReplacementNamed(AppRoutes.dashboard);
          },
          child: const Text('Entrar'),
        ),
      ),
    );
  }
}
