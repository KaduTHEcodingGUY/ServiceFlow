import 'package:flutter/material.dart';
import 'package:serviceflow/app/app_widget.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AppWidget());
}
